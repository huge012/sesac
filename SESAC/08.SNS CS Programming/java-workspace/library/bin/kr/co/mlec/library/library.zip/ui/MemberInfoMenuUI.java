package kr.co.mlec.library.ui;

public class MemberInfoMenuUI extends BaseUI {

	public void execute()
	{
		
	}
	
}
