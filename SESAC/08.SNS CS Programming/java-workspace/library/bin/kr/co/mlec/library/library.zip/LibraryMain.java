package kr.co.mlec.library;

import kr.co.mlec.library.ui.SelectMemberUI;

public class LibraryMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SelectMemberUI ui = new SelectMemberUI();
		ui.execute();
	}

}
