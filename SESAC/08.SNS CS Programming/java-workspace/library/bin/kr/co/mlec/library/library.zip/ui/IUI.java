package kr.co.mlec.library.ui;

public interface IUI {
	void execute();
}
