package kr.co.mlec.login.ui;

public interface ILoginUI {
	void execute();
}
