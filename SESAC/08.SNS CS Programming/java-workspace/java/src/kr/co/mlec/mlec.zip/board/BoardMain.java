package kr.co.mlec.board;

import kr.co.mlec.board.ui.BoardUI;
import kr.co.mlec.login.ui.LoginUI;

public class BoardMain {

	public static void main(String[] args) {
		
		//BoardUI board = new BoardUI();
		//board.execute();
		
		LoginUI log = new LoginUI();
		log.execute();
	}

}
