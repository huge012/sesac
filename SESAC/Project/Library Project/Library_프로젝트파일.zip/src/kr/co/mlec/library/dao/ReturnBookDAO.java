package kr.co.mlec.library.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import kr.co.mlec.library.util.ConnectionFactory;
import kr.co.mlec.library.util.JDBCClose;
import kr.co.mlec.library.vo.ManageVO;

public class ReturnBookDAO {

	private int SetRentInfo(Connection conn, ManageVO returnbook)
	{
		PreparedStatement pstmt = null;
		int result = 0;
		
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" insert into t_manage(no, book_code, id ) ");
			sql.append(" values(Numbering.nextval, ?, ? ) ");
			
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, returnbook.getBookCode());
			pstmt.setString(2, returnbook.getId());
			
			result = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCClose.stmtClose(pstmt);
		}
		
		return result;
	}	
	
	
	

	//반납일 현 시점으로 바꿔주기  (UpdateReturnDate로 이름,,바꿔)
	public int insertReturnInfo(Connection conn, ManageVO returnbook, int bookcode)
	{
		PreparedStatement pstmt = null;
		int result = 0;
	
		try {
			conn = new ConnectionFactory().getConnection();
		
			StringBuilder sql = new StringBuilder();
			sql.append("update t_manage ");
			sql.append("set return_date = sysdate ");
			sql.append("where book_code = ? and id = ? and rownum<=1 ");
			
			pstmt = conn.prepareStatement(sql.toString());
			
			pstmt.setInt(1, bookcode);
			pstmt.setString(2, returnbook.getId());
			
			result = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCClose.stmtClose(pstmt);
		}
		
		return result;
		}	
	
	//t_user에서 id찾아서 내가 빌린책에서 ++해주기
	private int updateUserReturn(Connection conn, ManageVO returnbook, int insert)
	{
		PreparedStatement pstmt = null;
		int result = 0;
		
		try {			
			StringBuilder sql = new StringBuilder();
			sql.append(" update t_user ");
			sql.append("set lending_book_num = lending_book_num + ? ");
			sql.append("where id = ? ");
			
			pstmt = conn.prepareStatement(sql.toString());
			
			pstmt.setInt(1, insert);
			pstmt.setString(2, returnbook.getId());
			
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCClose.stmtClose(pstmt);
		}
		return result;
	}
	
	
	//t_book에서 책 코드 찾아서 available책 ++해주기
	public int updateavailableBook(Connection conn, int bookcode, int insert)
	{
		PreparedStatement pstmt = null;
		int result = 0;
		
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("update t_books ");
			sql.append(" set available_book = available_book + ? ");
			sql.append("where book_code = ? ");
			
			pstmt = conn.prepareStatement(sql.toString());
			
			pstmt.setInt(1, insert);
			pstmt.setInt(2, bookcode);
			
			result = pstmt.executeUpdate();	
		
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCClose.stmtClose(pstmt);
		}
		
		return result;
	}

//-------------------------------------------------------------------------------
	/*대출 코드처럼 try~catch 써서

1. Manage 업뎃 메소드 호출
2. Book 갯수 (book number) 증가 메소드 호출  //updateuserrent를 호출하면된다고??
3. 내 렌트북 수 감소 메소드 호출
*/
	
	public int ReturnInfo(ManageVO returnbook)	
	{
		Connection conn = null;
		int result = 0;
		
			try {
				conn = new ConnectionFactory().getConnection();
				conn.setAutoCommit(false);
				
				result +=insertReturnInfo(conn, returnbook, returnbook.getBookCode());//반납일 변경
				result +=updateUserReturn(conn, returnbook, -1);   //사용자의 빌린 책 수 업뎃
				result +=updateavailableBook(conn, returnbook.getBookCode(), +1); // 빌려줄 수 있는 책 수 
							
				
				//이게 다 만족하면 commit하고 아니면 rollback
			if (result == 3)
			{
				conn.commit();
			}
			else
			{
				conn.rollback();
				result = 0;
				}
			} catch(Exception e) {
				e.printStackTrace();
			} finally {
				JDBCClose.connClose(conn);
			}


			return result;
			}
		
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

