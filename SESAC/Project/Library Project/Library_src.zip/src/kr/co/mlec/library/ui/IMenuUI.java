package kr.co.mlec.library.ui;

public interface IMenuUI {
	String menu();
}
